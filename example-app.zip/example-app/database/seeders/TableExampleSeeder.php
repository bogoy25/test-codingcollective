<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Examples;

class TableExampleSeeder extends Seeder
{
    public function run()
    {
        Examples::create([
            'name' => 'Dandy Akhmarienno Putra',
        ]);

        // Add more seed data as needed
    }
}
