<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Examples extends Model
{
    protected $fillable = ['name'];
}