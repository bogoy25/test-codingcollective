<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ThirdPartyController extends Controller
{
    public function integration(Request $request)
    {
        // Verify the Authorization Bearer Token
        $token = $request->bearerToken();
        
        $decodedToken = base64_decode($token);

        // Get the other parameters
        $orderId = $request->input('order_id');
        $amount = $request->input('amount');
        $time = $request->input('timestamp');

        // Perform integration with third party using the extracted data
        // Your integration logic goes here

        // Return a response indicating successful integration
        return response()->json([
            'status' => 1,
            'orderId' => $token,
            'amount' => $amount
        ]);
    }

}
