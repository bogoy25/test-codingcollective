<?php return array (
  'my-component' => 'App\\Http\\Livewire\\MyComponent',
);