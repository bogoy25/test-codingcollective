<?php $__env->startSection('container'); ?>
<div class="card"><br>
    <center><h3>--WITHDRAW--</h3></center>
  <div class="card-body">
    <form>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Total Dana</label>
        <div class="col-sm-10">
        <input type="text" class="form-control" readonly value="1.000.000">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Amount</label>
        <div class="col-sm-10">
        <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">No Account</label>
        <div class="col-sm-10">
        <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Name Account</label>
        <div class="col-sm-10">
        <input type="text" class="form-control">
        </div>
    </div>
        <button type="submit" class="btn btn-primary">Withdraw Now</button>
    </form>
  </div>
</div>



<?php if(session('success')): ?>
    <div class="alert alert-success mt-4">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/Laravel/example-app/resources/views/withdraw.blade.php ENDPATH**/ ?>