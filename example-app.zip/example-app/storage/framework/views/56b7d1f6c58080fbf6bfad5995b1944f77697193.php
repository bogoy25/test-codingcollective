<div class="card" style="margin: 20px;">
  <div class="card-header">
    Livewire Implementation
  </div>
  <div class="card-body">
    <h5 class="card-title">Special title treatment</h5>
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>

    <?php /**PATH /Users/macbook/Documents/Laravel/example-app/resources/views/livewire/my-component.blade.php ENDPATH**/ ?>