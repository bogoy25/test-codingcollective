@extends('main')

@section('container')
<div class="card"><br>
    <center><h3>--DEPOSIT--</h3></center>
  <div class="card-body">
    <form>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Amount</label>
        <div class="col-sm-10">
        <input type="number" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Card Number</label>
        <div class="col-sm-10">
        <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Expries CVV</label>
        <div class="col-sm-10">
        <input type="text" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label class="col-sm-2 col-form-label">Promo Code</label>
        <div class="col-sm-10">
        <input type="text" class="form-control">
        </div>
    </div>
        <button type="submit" class="btn btn-primary">Deposit Now</button>
    </form>
  </div>
</div>



@if (session('success'))
    <div class="alert alert-success mt-4">
        {{ session('success') }}
    </div>
@endif

@endsection